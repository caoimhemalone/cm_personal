<!-- Footer -->
	    <footer class="py-5 bg-dark">
	      <div class="container">
	        <p class="m-0 text-center text-white">Copyright &copy; key-vah 2018</p>
	        <p class="m-0 text-center text-white">Web Development & Design by key-vah</p>

	      </div>
  
    </footer>
   <!-- < ?php wp_footer(); ?> -->
  </body>
</html>
